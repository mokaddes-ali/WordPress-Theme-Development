<?php 
/**
 * 
 * 
 */
get_header();
?>
<?php 
 get_template_part('sections/hero');
 get_template_part('sections/about');
 get_template_part('sections/services');
 get_template_part('sections/videoSection');
 get_template_part('sections/team.member');
 get_template_part('/sections/packagePrice');
 get_template_part('sections/testimonial');
 get_template_part('sections/blog');

?>

<?php get_footer(); ?>





