<?php 
/**
 * Search results template
 */

get_header();
get_template_part('sections/pagesTitle');
?>


<h2><?php echo __('Search Results', 'lessonlms') ?></h2>


<?php get_footer(); ?>